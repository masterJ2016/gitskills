package com.redoor.upload;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * �� �� ��: UploadFrame.java
 * @description <����>
 * @author jixing
 * @version V1.0
 * @date 2016��9��29��
 */
public class UploadFrame extends JFrame implements ActionListener
{
	private JButton jbt_start_local_server;
	private JTextField textfield_local_port;
	private JTextField textfield_local_path;
	private JButton jbt_local_path;

	private JButton jbt_upload;
	private JButton jbt_upload_do;
	private JTextField textfield_ip;
	private JTextField textfield_port;
	private JTextField textfield;
	private JFileChooser fc;
	private String path = null;
	private String savePath = null;
	private UploadServer server;

	public UploadFrame()
	{
		try
		{
			//���ǰ�������óɵ�ǰϵͳƽ̨�����,Ҳ���ǳ������ĸ�ƽ̨����,��ʾ�Ĵ���,�Ի�����۽����ĸ�ƽ̨�����.
			UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName() );
		}
		catch ( ClassNotFoundException e )
		{
			e.printStackTrace();
		}
		catch ( InstantiationException e )
		{
			e.printStackTrace();
		}
		catch ( IllegalAccessException e )
		{
			e.printStackTrace();
		}
		catch ( UnsupportedLookAndFeelException e )
		{
			e.printStackTrace();
		}

		setTitle( "�ϴ�����" );
		setIconImage( Toolkit.getDefaultToolkit().getImage( "images/icon2.png" ) );
		setSize( 480, 220 );
		setResizable( false );
		WinCenter.center( this );
		getContentPane().setLayout( null );
		addWindowListener( new WindowAdapter() {
			@Override
			public void windowClosing( WindowEvent e )
			{
				System.exit( 0 );
				server.setFlag( false );
				jbt_start_local_server.setBackground( Color.RED );
				server.destroy();
			}
		} );

		jbt_start_local_server = new JButton( "�������ط�����" );
		jbt_start_local_server.setBounds( 10, 10, 120, 30 );
		jbt_start_local_server.addActionListener( this );
		getContentPane().add( jbt_start_local_server );
		jbt_start_local_server.setBackground( Color.RED );

		JLabel lblNewLabel_0 = new JLabel( "���ط������˿ڣ�" );
		lblNewLabel_0.setFont( new Font( "����", Font.PLAIN, 12 ) );
		lblNewLabel_0.setBounds( 150, 10, 100, 30 );
		getContentPane().add( lblNewLabel_0 );

		textfield_local_port = new JTextField();
		textfield_local_port.setBounds( 260, 10, 100, 30 );
		getContentPane().add( textfield_local_port );
		textfield_local_port.setColumns( 10 );
		textfield_local_port.setText( "11111" );

		JLabel lblNewLabel_3 = new JLabel( "���ñ���·����" );
		lblNewLabel_3.setFont( new Font( "����", Font.PLAIN, 12 ) );
		lblNewLabel_3.setBounds( 10, 50, 90, 30 );
		getContentPane().add( lblNewLabel_3 );

		textfield_local_path = new JTextField();
		textfield_local_path.setBounds( 100, 50, 300, 30 );
		getContentPane().add( textfield_local_path );
		textfield_local_path.setColumns( 10 );

		jbt_local_path = new JButton( "���" );
		jbt_local_path.setBounds( 410, 50, 60, 30 );
		jbt_local_path.addActionListener( this );
		getContentPane().add( jbt_local_path );
		/************************************************* server ********************************/
		JLabel lblNewLabel_4 = new JLabel( "-------------------------------------------------------------------------------------------" );
		lblNewLabel_4.setFont( new Font( "����", Font.PLAIN, 10 ) );
		lblNewLabel_4.setBackground( Color.lightGray );
		lblNewLabel_4.setBounds( 10, 90, 460, 10 );
		getContentPane().add( lblNewLabel_4 );
		/************************************************* client ********************************/
		JLabel lblNewLabel_1 = new JLabel( "IP��ַ��" );
		lblNewLabel_1.setFont( new Font( "����", Font.PLAIN, 12 ) );
		lblNewLabel_1.setBounds( 10, 100, 80, 30 );
		getContentPane().add( lblNewLabel_1 );

		textfield_ip = new JTextField();
		textfield_ip.setBounds( 90, 100, 100, 30 );
		getContentPane().add( textfield_ip );
		textfield_ip.setColumns( 10 );
		try
		{
			String ip = (String) Inet4Address.getLocalHost().getHostAddress();
			textfield_ip.setText( ip );
		}
		catch ( UnknownHostException e )
		{
			e.printStackTrace();
		}

		JLabel lblNewLabel_2 = new JLabel( "�˿ڣ�" );
		lblNewLabel_2.setFont( new Font( "����", Font.PLAIN, 12 ) );
		lblNewLabel_2.setBounds( 210, 100, 80, 30 );
		getContentPane().add( lblNewLabel_2 );

		textfield_port = new JTextField();
		textfield_port.setBounds( 260, 100, 100, 30 );
		getContentPane().add( textfield_port );
		textfield_port.setColumns( 10 );
		textfield_port.setText( "11111" );

		jbt_upload = new JButton( "���" );
		jbt_upload.setBounds( 10, 140, 60, 30 );
		jbt_upload.addActionListener( this );
		getContentPane().add( jbt_upload );
		textfield = new JTextField();
		textfield.setBounds( 80, 140, 300, 30 );
		getContentPane().add( textfield );
		textfield.setColumns( 10 );
		jbt_upload_do = new JButton( "�ϴ�" );
		jbt_upload_do.setBounds( 390, 140, 60, 30 );
		jbt_upload_do.addActionListener( this );
		getContentPane().add( jbt_upload_do );

	}

	public void actionPerformed( ActionEvent e )
	{

		if (e.getSource() == jbt_upload)
		{
			fc = new JFileChooser();
			fc.setDialogTitle( "��ѡ��Ҫ�ϴ����ļ�..." );
			fc.setApproveButtonText( "ȷ��" );
			fc.setFileSelectionMode( JFileChooser.FILES_ONLY );
			if (JFileChooser.APPROVE_OPTION == fc.showOpenDialog( this ))
			{
				path = fc.getSelectedFile().getPath();
				System.out.println( path );
				textfield.setText( path );
			}
		}
		if (e.getSource() == jbt_upload_do)
		{
			try
			{
				String ip = textfield_ip.getText();
				String port = textfield_port.getText();

				if (null != path && path.trim().length() > 0 || null != ip && ip.trim().length() > 0 || null != port && port.trim().length() > 0)
				{
					String mes = new UploadClient().doUpload( ip, port, path );
					JOptionPane.showMessageDialog( this, mes );
				}
				else
				{
					JOptionPane.showMessageDialog( this, "�ļ�·������Ϊ�գ�" );
				}
			}
			catch ( IOException e1 )
			{
				JOptionPane.showMessageDialog( this, "�ϴ�ʧ�ܣ�" );
				e1.printStackTrace();
			}

		}

		if (e.getSource() == jbt_local_path)
		{
			fc = new JFileChooser();
			fc.setDialogTitle( "��ѡ��Ҫ�ϴ����ļ�..." );
			fc.setApproveButtonText( "ȷ��" );
			fc.setFileSelectionMode( JFileChooser.DIRECTORIES_ONLY );
			if (JFileChooser.APPROVE_OPTION == fc.showOpenDialog( this ))
			{
				savePath = fc.getSelectedFile().getPath();
				textfield_local_path.setText( savePath );
			}
		}

		if (e.getSource() == jbt_start_local_server)//�������ط�����
		{
			String localPort = textfield_local_port.getText();
			if (null != localPort && localPort.trim().length() > 0 && null != savePath && savePath.trim().length() > 0)
			{
				try
				{
					if (null == server || !server.isAlive())
					{
						jbt_start_local_server.setBackground( Color.GREEN );
						server = new UploadServer( new Integer( localPort ) );
						server.setSavePath( savePath );
						server.setFlag( true );
						server.start();
						JOptionPane.showMessageDialog( this, "���ط�������������" );
					}
					else
					{
						jbt_start_local_server.setBackground( Color.RED );
						server.destroy();
					}
				}
				catch ( Exception e2 )
				{
					e2.printStackTrace();
					jbt_start_local_server.setBackground( Color.RED );
					JOptionPane.showMessageDialog( this, "���ط������쳣��" );
				}
			}
			else
			{
				JOptionPane.showMessageDialog( this, "����д���ط������˿ڻ򱣴�·����" );
			}
		}

	}

	public static void main( String[] args )
	{
		UploadFrame uframe = new UploadFrame();
		uframe.setVisible( true );
	}

}
